const { Command } = require('discord.js-commando');
const { RichEmbed } = require('discord.js');
const plotly = require('plotly')(process.env.PLOTLY_USER,process.env.PLOTLY_PASS);
const dateFormat = require('dateformat');
const logger = require('heroku-logger');
const request = require('request');

const errorMessage = require('../../modules/message/errorMessage.js');
const mongoConnection = require('../../modules/connection/mongoConnection.js');
const utils = require('../../modules/utils.js');
const fileManagement = require('../../modules/service/fileManagement.js');

const logName = '[WingGraph]';
const fileDir = '/images/graph/winggraph/';
const fileExtension = '.png';
const wgName = 'INTERSTELLAR';
const wingUrl = '';
const wingColor = '#f00000';
const UP = '⬆';
const DOWN = '⬇';
const EQUAL = '⬌';
let startGraphDate, endGraphDate;

module.exports = class WingGraphCommand extends Command {

    constructor(client) {
        super(client, {
            name: 'edigrafico',
            group: 'status',
            memberName: 'winggraph',
            description: 'Verify EDI Graph',
            guildOnly: true,
            patterns: [new RegExp('[a-zA-Z]')]
        });
    }

    async run(msg, args) {

        return;

        utils.logMessageUserExecuteCommand(logName, msg);

        if (!checkApplyRequirements()) {
            logger.warn(logName + ' not apply requirements');
            return errorMessage.sendSpecificClientErrorMessage(msg, 'Este comando está desabilitado.');
        }

        msg.channel.send({'embed': new RichEmbed()
            .setColor(wingColor)
            .setAuthor(utils.getUserNickName(msg), utils.getUserAvatar(msg))
            .setTimestamp()
            .setFooter('Fly safe cmdr!')
            .setDescription(':arrows_counterclockwise: Aguarde um instante, o gráfico está sendo gerado...')}).then(waitMessage => {
            
            msg.delete();
            
            const inicialDate = new Date();
            inicialDate.setDate(inicialDate.getDate() - 9);
            inicialDate.setUTCHours(0, 0, 0, 0);
            const query = {_id : { '$gte' : inicialDate }, wingName: wgName };
            
            mongoConnection.find(logName, query, 'wingData', (err, results) => {
                if (err) {
                    logger.error(logName + ' Error on retrieving informations', {'err': err});
                    waitMessage.delete();
                    return errorMessage.sendClientErrorMessage(msg);
                }
                const data = normalizeObjects(results);
                const graphOptions = getGraphOptions();
                
                plotly.plot(data, graphOptions, (err, res) => {
                    if (err) {
                        logger.error(logName + ' Error on plotly graph', {'err': err});
                        waitMessage.delete();
                        return errorMessage.sendClientErrorMessage(msg);
                    }

                    const imageUrl = res.url + '.png';

                    request.get({url: imageUrl, encoding: 'binary'}, (err, response, body) => {
                        if (err) {
                            logger.error(logName + ' Error get Imagem from plotly', {'err': err});
                            waitMessage.delete();
                            return errorMessage.sendClientErrorMessage(msg);
                        }

                        const now = dateFormat(utils.getUTCDateNow(), 'yyyymmddHHMMss');
                        const fullFilename =  now + '-' + utils.removeSpaces(wgName) + fileExtension;

                        fileManagement.saveFile(logName, body, fileDir, fullFilename, (err) => {
                            if (err) {
                                logger.error(logName + ' Error to save file = ' + fileDir + fullFilename, {'err': err});
                                waitMessage.delete();
                                return errorMessage.sendClientErrorMessage(msg);
                            }

                            let imageAddress = process.env.BASE_URL + fileDir + fullFilename;
                            logger.info(logName + ' Image address: ' + imageAddress);
                            
                            let embed = new RichEmbed()
                                .setTitle('**Gráfico de influências da ' + wgName + '**')
                                .setAuthor(utils.getUserNickName(msg), utils.getUserAvatar(msg))
                                .setDescription('Dados extraídos do [EDDB](' + wingUrl + ')')
                                .setImage(imageAddress)
                                .setColor(wingColor)
                                .setTimestamp()
                                .setFooter('Fly safe cmdr!');
                            
                            onlyInDev(msg, imageAddress);
                            
                            logger.info(logName + ' Finished process to generate wing graph');
                            waitMessage.delete();
                            return msg.embed(embed);
                        });
                    });
                    logger.info(logName + ' Finished process to generate graph');
                });
            });
        }).catch(console.log);

        const onlyInDev = (msg, imageAddress) => {
            if (process.env.ENVIRONMENT === 'DEV') {
                msg.channel.send('', {
                    file: imageAddress
                });
            }
        }

        const normalizeObjects = (results) => {
            const map = [];
            let count = 0;
            const lastButOneInfluence = [];
            for(let result of results) {
                count = count+1;
                const date = result._id;
                for(let info of result.infos) {
                    const influence = info.influence;
                    if (map[info.systemName] == null) {
                        startGraphDate = utils.getUTCDate(date);
                        map[info.systemName] = {
                            influence: influence,
                            name: info.systemName,
                            y: [
                                influence
                            ],
                            x: [
                                date
                            ],
                            marker: {
                                size: 8
                            },
                            mode: 'lines+markers',
                            line: {
                                shape: 'linear'
                            },
                            type: 'scatter'
                        };
                    } else {
                        endGraphDate = utils.getUTCDate(result.lastUpdate);
                        map[info.systemName].influence = influence;
                        map[info.systemName].y.push(influence);
                        map[info.systemName].x.push(date);
                        if (count > 1) {
                            let name = ' ' + treatInfluence(influence) + utils.rpad('%', 4) + info.systemName;
                            let signal = EQUAL;
                            if (lastButOneInfluence[info.systemName] > influence) {
                                signal = DOWN;
                            } else if (lastButOneInfluence[info.systemName] < influence) {
                                signal = UP;
                            }
                            map[info.systemName].name = signal + name;
                        }
                        lastButOneInfluence[info.systemName] = influence;
                    }
                }
            }
            let resultNormalized = [];
            for (let key in map) {
                resultNormalized.push(map[key]);
            }
            resultNormalized.sort(sortFunction);
            return resultNormalized;
        }

        const sortFunction = (a, b) => {
            if (a.influence === b.influence) {
                return 0;
            } else {
                return (a.influence > b.influence) ? -1 : 1;
            }
        }

        const treatInfluence = (influence) => {
            let inf = influence;
            if (inf.toString().indexOf('.') == -1) {
                inf += '.0';
            }
            return utils.lpad(inf, 6);
        }

        const getGraphOptions = () => {
            return {
                fileopt : 'overwrite', 
                filename : 'cwgraph',
                style: {
                    type: 'scatter'
                },
                layout: {
                    title: wgName + ' - período: ' + 
                        dateFormat(startGraphDate, 'dd/mm/yyyy') +
                        ' à ' + dateFormat(endGraphDate, 'dd/mm/yyyy') + ' UTC',
                    legend: {
                        font: {
                            size: 12
                        },
                        borderwidth: 1
                    },
                    xaxis: {
                        title: 'Informações atualizadas pela última vez às ' + 
                                dateFormat(endGraphDate, 'HH:MM') + ' UTC',
                        tickformat: '%d/%m',
                        nticks: 11,
                        type: 'date',
                        autorange: true,
                        range: [
                            '2017-07-01',
                            '2017-07-10'
                        ]
                    },
                    yaxis: {
                        ticksuffix: ' %',
                        tickmode: 'linear',
                        dtick: 10,
                        range: [
                            -1,
                            101
                        ],
                        type: 'linear',
                        autorange: false
                    }
                }
            };
        }

        function checkApplyRequirements() {
            return process.env.BASE_URL && process.env.PLOTLY_USER && process.env.PLOTLY_PASS;
        }
    }
}